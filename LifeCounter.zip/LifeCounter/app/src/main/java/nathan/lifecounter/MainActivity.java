package nathan.lifecounter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity implements View.OnClickListener {
int lifeCounter1 = 20;
    int lifeCounter2= 20;
    int change = 0;
    Button mePlusFive,meMinusOne,mePlusOne,meMinusFive,opPlusFive,opMinusOne,opPlusOne,opMinusFive;
    Button reset;
    @Override

    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    //declare me buttons
        mePlusFive = (Button) findViewById(R.id.button);

        meMinusOne = (Button) findViewById(R.id.button2);

        mePlusOne = (Button) findViewById(R.id.button3);

        meMinusFive = (Button) findViewById(R.id.button4);
    //declare opponent buttons
        opPlusFive = (Button) findViewById(R.id.button5);

        opMinusOne = (Button) findViewById(R.id.button8);

        opPlusOne = (Button) findViewById(R.id.button7);

        opMinusFive = (Button)findViewById(R.id.button6);

        //declare all the listeners on created buttons
        mePlusFive.setOnClickListener(this);
        meMinusOne.setOnClickListener(this);
        mePlusOne.setOnClickListener(this);
        meMinusFive.setOnClickListener(this);
        opPlusFive.setOnClickListener(this);
        opMinusOne.setOnClickListener(this);
        opPlusOne.setOnClickListener(this);
        opMinusFive.setOnClickListener(this);
// declare reset button
        reset = (Button) findViewById(R.id.button9);
        reset.setOnClickListener(this);

    }


@Override

    public void onClick(View v)
    {

        final TextView tv = (TextView) findViewById(R.id.textView);
        final TextView tv2 = (TextView) findViewById(R.id.textView2);
        switch(v.getId())
        {
            case R.id.button:
                change = 5;
                setLife1(change);
                tv.setText(String.valueOf(getLifeCounter1()));
                break;

            case R.id.button2:
                change = -1;
                setLife1(change);
                tv.setText(String.valueOf(getLifeCounter1()));
                break;
            case R.id.button3:
                change = 1;
                setLife1(change);
                tv.setText(String.valueOf(getLifeCounter1()));
                break;
            case R.id.button4:
                change = -5;
                setLife1(change);
                tv.setText(String.valueOf(getLifeCounter1()));
                break;
            case R.id.button5:
                change = 5;
                setLife2(change);
                tv2.setText(String.valueOf(getLifeCounter2()));
                break;
            case R.id.button6:
                change = -5;
                setLife2(change);
                tv2.setText(String.valueOf(getLifeCounter2()));
                break;
            case R.id.button7:
                change = 1;
                setLife2(change);
                tv2.setText(String.valueOf(getLifeCounter2()));
                break;
            case R.id.button8:
                change = -1;
                setLife2(change);
                tv2.setText(String.valueOf(getLifeCounter2()));
                break;
            case R.id.button9:
                resetLife1();
                resetLife2();
                tv.setText(String.valueOf(getLifeCounter1()));
                tv2.setText(String.valueOf(getLifeCounter2()));
                break;



        }

    }
    void setLife1(int change)
    {
        lifeCounter1 = lifeCounter1 + change;
    }
    void setLife2(int change) { lifeCounter2 = lifeCounter2 + change;}
    int getLifeCounter1()
    {
        return lifeCounter1;
    }
    int getLifeCounter2() { return lifeCounter2; }
    void resetLife1() { lifeCounter1 = 20;}
    void resetLife2() { lifeCounter2 = 20;}
}


