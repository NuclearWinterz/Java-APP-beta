package com.example.nathan.myapplication;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import android.widget.TextView;
public class Buttons extends FullscreenActivity implements View.OnClickListener
{
    Button b1,b2,b3,b4;
    private int lifeCounter = 20;
    int change = 0;
@Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        TextView tv =(TextView)findViewById(R.id.textView);
        b1=(Button)findViewById(R.id.button);

        b2=(Button)findViewById(R.id.button2);

        b3 =(Button)findViewById(R.id.button3);

        b4 =(Button)findViewById(R.id.button4);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        b4.setOnClickListener(this);

    }




    public void onClick(View v)
    {
        // TODO Auto-generated method stub
        TextView tv = new TextView(this);

        switch(v.getId())
        {
            case R.id.button:
                change = 5;
                setLife(change);
               tv.setText(String.valueOf(getLifeCounter()));
                break;

            case R.id.button2:
                change = -1;
                setLife(change);
                tv.setText(String.valueOf(getLifeCounter()));
                break;
            case R.id.button3:
                change = 1;
                setLife(change);
                tv.setText(String.valueOf(getLifeCounter()));
                break;
            case R.id.button4:
                change = -5;
                setLife(change);
                tv.setText(String.valueOf(getLifeCounter()));
                break;
            default:
                break;

        }

    }
    void setLife(int change)
    {
        lifeCounter = lifeCounter + change;
    }
    int getLifeCounter()
    {
        return lifeCounter;
    }
}